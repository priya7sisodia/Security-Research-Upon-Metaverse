# Security-Research-upon-the-Metaverse
The Metaverse (future version of the internet) is a persistent, online, three-dimensional reality that integrates numerous virtual spaces. Video games provide the 
closest metaverse experience presently, emphasis on 3D virtual reality.
Our contribution starts by analyzing the foundations of the Metaverse. Metaverse will become an integral part of every person’s life. But people don’t have the required knowledge of Cyber Security, they don’t know how to secure themselves and how secure they are in this virtual world. . There is no single solution to the problem of making the Metaverse a safer place.
This project work will compensate for their lack of knowledge regarding the security issues in Metaverse and it will provide information and solution for the safety of their privacy, data, and personal information.
